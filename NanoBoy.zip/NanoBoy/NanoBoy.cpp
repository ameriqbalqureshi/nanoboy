#include "NanoBoy.h"

NanoBoy::NanoBoy()
#ifdef NANOboy_USE_SSD1306
  : displayObj(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1)
#else
  : displayObj(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1)
#endif
{}

void NanoBoy::begin() {
#ifdef NANOboy_USE_SSD1306
  displayObj.begin(SSD1306_SWITCHCAPVCC, 0x3C);
#else
  displayObj.begin(0x3C, true);
#endif
  displayObj.clearDisplay();
  displayObj.setTextColor(COLOR_WHITE);
  displayObj.display();

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  pinMode(BTN_A, INPUT_PULLUP);
  pinMode(BTN_B, INPUT_PULLUP);
}

void NanoBoy::clear() {
  displayObj.clearDisplay();
}

void NanoBoy::display() {
  displayObj.display();
}

void NanoBoy::setCursor(int x, int y) {
  displayObj.setCursor(x, y);
  //displayObj.setTextColor(COLOR_WHITE);
}
void NanoBoy::setTextColor(int c){
  displayObj.setTextColor(c);
}
void NanoBoy::setTextSize(int x){
  displayObj.setTextSize(x);
}
void NanoBoy::print(const char *text) {
  displayObj.print(text);
  }

void NanoBoy::print(const String &text) {
  displayObj.print(text.c_str());
}

void NanoBoy::print(int num) {
  displayObj.print(num);
}

void NanoBoy::print(float num) {
  displayObj.print(num);
}

void NanoBoy::drawText(int x, int y, const char *text) {
  displayObj.setCursor(x, y) ; 
  displayObj.print(text);
}

void NanoBoy::drawText(int x, int y, const String &text) {
  displayObj.setCursor(x, y) ; 
  displayObj.print(text);
}
void NanoBoy::drawPixel(int x, int y, int color) {
  displayObj.drawPixel(x, y, color);
}

void NanoBoy::drawLine(int x0, int y0, int x1, int y1, int color) {
  displayObj.drawLine(x0, y0, x1, y1, color);
}

void NanoBoy::drawRect(int x, int y, int w, int h, int color) {
  displayObj.drawRect(x, y, w, h, color);
}

void NanoBoy::fillRect(int x, int y, int w, int h, int color) {
  displayObj.fillRect(x, y, w, h, color);
}

void NanoBoy::drawCircle(int x, int y, int r, int color) {
  displayObj.drawCircle(x, y, r, color);
}

void NanoBoy::fillCircle(int x, int y, int r, int color) {
  displayObj.fillCircle(x, y, r, color);
}

void NanoBoy::drawSprite(const Sprite &sprite) {
  if (!sprite.active) return;
  displayObj.drawBitmap(sprite.x, sprite.y, sprite.bitmap,
                        sprite.w, sprite.h, COLOR_WHITE);
}

bool NanoBoy::checkCollision(const Sprite &a, const Sprite &b) {
  if (!a.active || !b.active) return false;
  return !(b.x > (a.x + a.w - 1) ||
           (b.x + b.w - 1) < a.x ||
           b.y > (a.y + a.h - 1) ||
           (b.y + b.h - 1) < a.y);
}

bool NanoBoy::buttonPressed(int btn) {
  return digitalRead(btn) == LOW;
}

void NanoBoy::setLED(bool state) {
  digitalWrite(LED_PIN, state ? HIGH : LOW);
}

void NanoBoy::beep(int freq, int dur) {
  tone(BUZZER_PIN, freq, dur);
}

void NanoBoy::beep(int dur) {
  tone(BUZZER_PIN, 1000, dur);
}

void NanoBoy::drawBarGraph(int x, int y, int w, int h, int minVal, int maxVal, int value) {
  if (value < minVal) value = minVal;
  if (value > maxVal) value = maxVal;

  int fillW = map(value, minVal, maxVal, 0, w);

  // Outline of the bar
  displayObj.drawRect(x, y, w, h, COLOR_WHITE);

  // Filled portion
  if (fillW > 0) {
    displayObj.fillRect(x + 1, y + 1, fillW - 2, h - 2, COLOR_WHITE);
  }
}

