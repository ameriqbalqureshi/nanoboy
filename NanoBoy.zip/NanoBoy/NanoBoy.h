#ifndef NANOboy_H
#define NANOboy_H

#include <Arduino.h>

// ========== SELECT DISPLAY TYPE ==========
// Uncomment one line only
// #define NANOboy_USE_SSD1306    // for 0.96" OLED
#define NANOboy_USE_SH1106   // for 1.3" OLED
// =========================================

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// Unified color constants
#define COLOR_WHITE 1
#define COLOR_BLACK 0

// Pin definitions
#define BTN_UP    2
#define BTN_DOWN  3
#define BTN_LEFT  4
#define BTN_RIGHT 5
#define BTN_A     6
#define BTN_B     7
#define LED_PIN   8
#define BUZZER_PIN 9

#define _T_SIZE 8  // tile size default

#ifdef NANOboy_USE_SSD1306
  #include <Adafruit_SSD1306.h>
#else
  #include <Adafruit_SH110X.h>
#endif
#include <Adafruit_GFX.h>

struct Sprite {
  int x, y, w, h;
  const uint8_t *bitmap;
  bool active;
};

class NanoBoy {
public:
  NanoBoy();
  void begin();

  void clear();
  void display();

  void setCursor(int x, int y);
  void setTextSize(int x);
  void setTextColor(int c);
  void print(const char *text);
  void print(int num);
  void print(float num);
  void print(const String &text);
  void drawText(int x, int y, const char *text);
  void drawText(int x, int y, const String &text);

  void drawPixel(int x, int y, int color);
  void drawLine(int x0, int y0, int x1, int y1, int color=COLOR_WHITE);
  void drawRect(int x, int y, int w, int h, int color=COLOR_WHITE);
  void fillRect(int x, int y, int w, int h, int color=COLOR_WHITE);
  void drawCircle(int x, int y, int r, int color=COLOR_WHITE);
  void fillCircle(int x, int y, int r, int color=COLOR_WHITE);

  void drawSprite(const Sprite &sprite);
  bool checkCollision(const Sprite &a, const Sprite &b);

  bool buttonPressed(int btn);
  void setLED(bool state);
  void beep(int freq, int dur);
  void beep(int dur);

private:
#ifdef NANOboy_USE_SSD1306
  Adafruit_SSD1306 displayObj;
#else
  Adafruit_SH1106G displayObj;
#endif
};

#endif
